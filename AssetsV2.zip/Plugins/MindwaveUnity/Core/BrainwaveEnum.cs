﻿public enum Brainwave
{
	Delta,
	Theta,
	LowAlpha,
	HighAlpha,
	LowBeta,
	HighBeta,
	LowGamma,
	HighGamma
}