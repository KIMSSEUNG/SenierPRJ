﻿using System;

[AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
public class DebugGUIPrintAttribute : Attribute { }