using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DebugGUI_UI : MonoBehaviour
{
    //[DebugGUIGraph(min: -2, max: 1, r: 0, g: 1, b: 1, autoScale: true)]
    //float CosProperty { get { return Mathf.Cos(Time.time * 6); } }

    //// Also works for expression-bodied properties in .Net 4.6+
    //[DebugGUIGraph(min: -1, max: 1, r: 1, g: 0.3f, b: 1)]
    //float SinProperty => Mathf.Sin((Time.time + Mathf.PI / 2) * 6);

}
